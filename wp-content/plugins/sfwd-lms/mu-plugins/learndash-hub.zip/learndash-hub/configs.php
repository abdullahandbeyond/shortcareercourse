<?php

const BASE_DOMAIN    = 'learndash.com';
const LICENSING_SITE = 'https://checkout.' . BASE_DOMAIN;

const BASE_REST = 'learndash/v1';
